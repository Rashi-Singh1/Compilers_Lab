#define MAX 10000
void insert(char* str);
int lookup(char* str);
void print();
